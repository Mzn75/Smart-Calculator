﻿Public Class Form9

    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label4.Visible = False
        rslt_lbl.Visible = False
    End Sub

    'SideBar 
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If SplitContainer1.SplitterDistance > 60 Then
            SplitContainer1.SplitterDistance -= 10
        Else
            Timer1.Enabled = False
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If SplitContainer1.SplitterDistance < 250 Then
            SplitContainer1.SplitterDistance += 10
        Else
            Timer2.Enabled = False
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If SplitContainer1.SplitterDistance > 60 Then
            Timer1.Enabled = True
        Else
            Timer2.Enabled = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Visible = False
        Form1.Visible = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Visible = False
        Form2.Visible = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Visible = False
        Form3.Visible = True
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Visible = False
        Form4.Visible = True
    End Sub 'End SideBar

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click

        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        Else
            Dim nm1 = Double.Parse(TextBox1.Text)
            Dim nm2 = Double.Parse(TextBox2.Text)
            Dim nm3 = Double.Parse(TextBox3.Text)
            Dim res As Double

            res = 0.5 * (nm1 + nm2) * nm3
            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        Else
            Dim nm1 = Double.Parse(TextBox1.Text)
            Dim nm2 = Double.Parse(TextBox2.Text)
            Dim nm3 = Double.Parse(TextBox3.Text)
            Dim nm4 = Double.Parse(TextBox4.Text)
            Dim res As Double

            res = nm1 + nm2 + nm3 + nm4
            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub reset_btn_Click(sender As Object, e As EventArgs) Handles reset_btn.Click

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()

        Label4.Visible = False
        rslt_lbl.Visible = False
    End Sub

End Class