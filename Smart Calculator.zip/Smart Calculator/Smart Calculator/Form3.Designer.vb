﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form3))
        Panel1 = New Panel()
        Button5 = New Button()
        Label3 = New Label()
        SplitContainer1 = New SplitContainer()
        Button4 = New Button()
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Label6 = New Label()
        Label7 = New Label()
        Button14 = New Button()
        Button13 = New Button()
        Button12 = New Button()
        Button11 = New Button()
        Button10 = New Button()
        PictureBox5 = New PictureBox()
        Button9 = New Button()
        Button7 = New Button()
        Button6 = New Button()
        PictureBox11 = New PictureBox()
        PictureBox10 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox4 = New PictureBox()
        PictureBox3 = New PictureBox()
        Label1 = New Label()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        Panel1.SuspendLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).BeginInit()
        SplitContainer1.Panel1.SuspendLayout()
        SplitContainer1.Panel2.SuspendLayout()
        SplitContainer1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Orange
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(-1, -1)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(956, 49)
        Panel1.TabIndex = 0
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatStyle = FlatStyle.Flat
        Button5.ForeColor = Color.Orange
        Button5.Image = My.Resources.Resources.list1
        Button5.Location = New Point(908, -1)
        Button5.Name = "Button5"
        Button5.Size = New Size(48, 47)
        Button5.TabIndex = 6
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Rubik Black", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.Control
        Label3.Location = New Point(372, 10)
        Label3.Name = "Label3"
        Label3.Size = New Size(237, 64)
        Label3.TabIndex = 5
        Label3.Text = "الــحــاســبــة الــذكــيــة" & vbCrLf & vbCrLf
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' SplitContainer1
        ' 
        SplitContainer1.Location = New Point(-1, 44)
        SplitContainer1.Name = "SplitContainer1"
        ' 
        ' SplitContainer1.Panel1
        ' 
        SplitContainer1.Panel1.BackColor = Color.Orange
        SplitContainer1.Panel1.Controls.Add(Button4)
        SplitContainer1.Panel1.Controls.Add(PictureBox1)
        SplitContainer1.Panel1.Controls.Add(Button1)
        SplitContainer1.Panel1.Controls.Add(Button3)
        SplitContainer1.Panel1.Controls.Add(Button2)
        SplitContainer1.Panel1.RightToLeft = RightToLeft.Yes
        ' 
        ' SplitContainer1.Panel2
        ' 
        SplitContainer1.Panel2.BackColor = SystemColors.ActiveCaption
        SplitContainer1.Panel2.Controls.Add(Label6)
        SplitContainer1.Panel2.Controls.Add(Label7)
        SplitContainer1.Panel2.Controls.Add(Button14)
        SplitContainer1.Panel2.Controls.Add(Button13)
        SplitContainer1.Panel2.Controls.Add(Button12)
        SplitContainer1.Panel2.Controls.Add(Button11)
        SplitContainer1.Panel2.Controls.Add(Button10)
        SplitContainer1.Panel2.Controls.Add(PictureBox5)
        SplitContainer1.Panel2.Controls.Add(Button9)
        SplitContainer1.Panel2.Controls.Add(Button7)
        SplitContainer1.Panel2.Controls.Add(Button6)
        SplitContainer1.Panel2.Controls.Add(PictureBox11)
        SplitContainer1.Panel2.Controls.Add(PictureBox10)
        SplitContainer1.Panel2.Controls.Add(PictureBox8)
        SplitContainer1.Panel2.Controls.Add(PictureBox7)
        SplitContainer1.Panel2.Controls.Add(PictureBox6)
        SplitContainer1.Panel2.Controls.Add(PictureBox4)
        SplitContainer1.Panel2.Controls.Add(PictureBox3)
        SplitContainer1.Panel2.Controls.Add(Label1)
        SplitContainer1.Panel2.RightToLeft = RightToLeft.Yes
        SplitContainer1.RightToLeft = RightToLeft.Yes
        SplitContainer1.Size = New Size(956, 598)
        SplitContainer1.SplitterDistance = 263
        SplitContainer1.TabIndex = 1
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = SystemColors.Control
        Button4.Image = My.Resources.Resources.mathematician
        Button4.ImageAlign = ContentAlignment.MiddleRight
        Button4.Location = New Point(3, 441)
        Button4.Name = "Button4"
        Button4.Size = New Size(277, 42)
        Button4.TabIndex = 11
        Button4.Text = "الــنظــريــات"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.calculator__1_
        PictureBox1.Location = New Point(105, 34)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(69, 73)
        PictureBox1.TabIndex = 7
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.Control
        Button1.Image = My.Resources.Resources.home
        Button1.ImageAlign = ContentAlignment.MiddleRight
        Button1.Location = New Point(3, 165)
        Button1.Name = "Button1"
        Button1.Size = New Size(277, 42)
        Button1.TabIndex = 8
        Button1.Text = "الصفحة الرئيسية"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = SystemColors.Control
        Button3.Image = My.Resources.Resources.prototype
        Button3.ImageAlign = ContentAlignment.MiddleRight
        Button3.Location = New Point(3, 345)
        Button3.Name = "Button3"
        Button3.Size = New Size(277, 42)
        Button3.TabIndex = 10
        Button3.Text = "الــهــنــدســة"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = SystemColors.Control
        Button2.Image = My.Resources.Resources.calculator__2_
        Button2.ImageAlign = ContentAlignment.MiddleRight
        Button2.Location = New Point(3, 259)
        Button2.Name = "Button2"
        Button2.Size = New Size(277, 42)
        Button2.TabIndex = 9
        Button2.Text = "الأرقــــــــام"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.ForeColor = Color.DarkGreen
        Label6.Location = New Point(84, 571)
        Label6.Name = "Label6"
        Label6.Size = New Size(45, 16)
        Label6.TabIndex = 29
        Label6.Text = "Mz_75"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(5, 571)
        Label7.Name = "Label7"
        Label7.Size = New Size(73, 16)
        Label7.TabIndex = 28
        Label7.Text = "Powered By "
        ' 
        ' Button14
        ' 
        Button14.Cursor = Cursors.Hand
        Button14.FlatAppearance.BorderColor = SystemColors.ActiveCaption
        Button14.FlatAppearance.CheckedBackColor = Color.Teal
        Button14.FlatStyle = FlatStyle.Flat
        Button14.Font = New Font("Rubik", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Button14.ForeColor = SystemColors.Control
        Button14.Location = New Point(243, 412)
        Button14.Name = "Button14"
        Button14.Size = New Size(60, 50)
        Button14.TabIndex = 19
        Button14.Text = "الكرة"
        Button14.UseVisualStyleBackColor = True
        ' 
        ' Button13
        ' 
        Button13.Cursor = Cursors.Hand
        Button13.FlatAppearance.BorderColor = SystemColors.ActiveCaption
        Button13.FlatAppearance.CheckedBackColor = Color.Teal
        Button13.FlatStyle = FlatStyle.Flat
        Button13.Font = New Font("Rubik", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Button13.ForeColor = SystemColors.Control
        Button13.Location = New Point(552, 412)
        Button13.Name = "Button13"
        Button13.Size = New Size(101, 50)
        Button13.TabIndex = 18
        Button13.Text = "شبه المنحرف"
        Button13.UseVisualStyleBackColor = True
        ' 
        ' Button12
        ' 
        Button12.Cursor = Cursors.Hand
        Button12.FlatAppearance.BorderColor = SystemColors.ActiveCaption
        Button12.FlatAppearance.CheckedBackColor = Color.Teal
        Button12.FlatStyle = FlatStyle.Flat
        Button12.Font = New Font("Rubik", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Button12.ForeColor = SystemColors.Control
        Button12.Location = New Point(389, 412)
        Button12.Name = "Button12"
        Button12.Size = New Size(102, 49)
        Button12.TabIndex = 17
        Button12.Text = "متوازي الأضلاع"
        Button12.UseVisualStyleBackColor = True
        ' 
        ' Button11
        ' 
        Button11.Cursor = Cursors.Hand
        Button11.FlatAppearance.BorderColor = SystemColors.ActiveCaption
        Button11.FlatAppearance.CheckedBackColor = Color.Teal
        Button11.FlatStyle = FlatStyle.Flat
        Button11.Font = New Font("Rubik", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Button11.ForeColor = SystemColors.Control
        Button11.Location = New Point(253, 195)
        Button11.Name = "Button11"
        Button11.Size = New Size(60, 49)
        Button11.TabIndex = 16
        Button11.Text = "الدائرة"
        Button11.UseVisualStyleBackColor = True
        ' 
        ' Button10
        ' 
        Button10.Cursor = Cursors.Hand
        Button10.FlatAppearance.BorderColor = SystemColors.ActiveCaption
        Button10.FlatAppearance.CheckedBackColor = Color.Teal
        Button10.FlatStyle = FlatStyle.Flat
        Button10.Font = New Font("Rubik", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Button10.ForeColor = SystemColors.Control
        Button10.Location = New Point(398, 195)
        Button10.Name = "Button10"
        Button10.Size = New Size(83, 49)
        Button10.TabIndex = 15
        Button10.Text = "المستطيل"
        Button10.UseVisualStyleBackColor = True
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Image = My.Resources.Resources.square
        PictureBox5.Location = New Point(534, 53)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(136, 136)
        PictureBox5.TabIndex = 4
        PictureBox5.TabStop = False
        ' 
        ' Button9
        ' 
        Button9.Cursor = Cursors.Hand
        Button9.FlatAppearance.BorderColor = SystemColors.ActiveCaption
        Button9.FlatAppearance.CheckedBackColor = Color.Teal
        Button9.FlatStyle = FlatStyle.Flat
        Button9.Font = New Font("Rubik", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Button9.ForeColor = SystemColors.Control
        Button9.Location = New Point(84, 195)
        Button9.Name = "Button9"
        Button9.Size = New Size(60, 49)
        Button9.TabIndex = 14
        Button9.Text = "المثلث"
        Button9.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Cursor = Cursors.Hand
        Button7.FlatAppearance.BorderColor = SystemColors.ActiveCaption
        Button7.FlatAppearance.CheckedBackColor = Color.Teal
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Font = New Font("Rubik", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Button7.ForeColor = SystemColors.Control
        Button7.Location = New Point(66, 412)
        Button7.Name = "Button7"
        Button7.Size = New Size(80, 50)
        Button7.TabIndex = 12
        Button7.Text = "المكعب"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Cursor = Cursors.Hand
        Button6.FlatAppearance.BorderColor = SystemColors.ActiveCaption
        Button6.FlatAppearance.CheckedBackColor = Color.Teal
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Rubik", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.ForeColor = SystemColors.Control
        Button6.Location = New Point(575, 195)
        Button6.Name = "Button6"
        Button6.Size = New Size(60, 49)
        Button6.TabIndex = 11
        Button6.Text = "المربع"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' PictureBox11
        ' 
        PictureBox11.Image = My.Resources.Resources.rubik
        PictureBox11.Location = New Point(42, 270)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(136, 136)
        PictureBox11.TabIndex = 10
        PictureBox11.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.Image = My.Resources.Resources.beach_ball
        PictureBox10.Location = New Point(213, 270)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(136, 136)
        PictureBox10.TabIndex = 9
        PictureBox10.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.Image = My.Resources.Resources.circle
        PictureBox8.Location = New Point(213, 53)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(136, 136)
        PictureBox8.TabIndex = 7
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.Image = My.Resources.Resources.triangle
        PictureBox7.Location = New Point(42, 53)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(136, 136)
        PictureBox7.TabIndex = 6
        PictureBox7.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Image = My.Resources.Resources.parallelogram
        PictureBox6.Location = New Point(372, 270)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(136, 136)
        PictureBox6.TabIndex = 5
        PictureBox6.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = My.Resources.Resources.trapezoid
        PictureBox4.Location = New Point(534, 269)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(136, 136)
        PictureBox4.TabIndex = 3
        PictureBox4.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = My.Resources.Resources.rectangle
        PictureBox3.Location = New Point(372, 53)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(136, 136)
        PictureBox3.TabIndex = 2
        PictureBox3.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(534, 7)
        Label1.Name = "Label1"
        Label1.Size = New Size(154, 29)
        Label1.TabIndex = 0
        Label1.Text = "إخــتــر الــشــكــل"
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 1
        ' 
        ' Timer2
        ' 
        Timer2.Interval = 1
        ' 
        ' Form3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(955, 640)
        Controls.Add(SplitContainer1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.Fixed3D
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form3"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Smart Calculator | الهندسة"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        SplitContainer1.Panel1.ResumeLayout(False)
        SplitContainer1.Panel2.ResumeLayout(False)
        SplitContainer1.Panel2.PerformLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).EndInit()
        SplitContainer1.ResumeLayout(False)
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents Label3 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button13 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents Button14 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Button5 As Button
End Class
