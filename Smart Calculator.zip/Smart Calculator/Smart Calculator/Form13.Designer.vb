﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form13
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form13))
        Timer2 = New Timer(components)
        Timer1 = New Timer(components)
        Button3 = New Button()
        Label6 = New Label()
        Label7 = New Label()
        Label1 = New Label()
        Button4 = New Button()
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button2 = New Button()
        SplitContainer1 = New SplitContainer()
        reset_btn = New Button()
        rslt_lbl = New Label()
        Label4 = New Label()
        btn3 = New Button()
        btn2 = New Button()
        btn1 = New Button()
        Label2 = New Label()
        PictureBox2 = New PictureBox()
        TextBox3 = New TextBox()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        Label3 = New Label()
        Panel1 = New Panel()
        Button5 = New Button()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).BeginInit()
        SplitContainer1.Panel1.SuspendLayout()
        SplitContainer1.Panel2.SuspendLayout()
        SplitContainer1.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Timer2
        ' 
        Timer2.Interval = 1
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 1
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = SystemColors.Control
        Button3.Image = My.Resources.Resources.prototype
        Button3.ImageAlign = ContentAlignment.MiddleRight
        Button3.Location = New Point(3, 269)
        Button3.Name = "Button3"
        Button3.Size = New Size(277, 42)
        Button3.TabIndex = 15
        Button3.Text = "الــهــنــدســة"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.ForeColor = Color.DarkGreen
        Label6.Location = New Point(79, 380)
        Label6.Name = "Label6"
        Label6.Size = New Size(45, 16)
        Label6.TabIndex = 29
        Label6.Text = "Mz_75"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(3, 380)
        Label7.Name = "Label7"
        Label7.Size = New Size(73, 16)
        Label7.TabIndex = 28
        Label7.Text = "Powered By "
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(402, 6)
        Label1.Name = "Label1"
        Label1.Size = New Size(170, 29)
        Label1.TabIndex = 0
        Label1.Text = "أدخـل الـمـعـطـيـات"
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = SystemColors.Control
        Button4.Image = My.Resources.Resources.mathematician
        Button4.ImageAlign = ContentAlignment.MiddleRight
        Button4.Location = New Point(3, 354)
        Button4.Name = "Button4"
        Button4.Size = New Size(277, 42)
        Button4.TabIndex = 16
        Button4.Text = "الــنظــريــات"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.calculator__1_
        PictureBox1.Location = New Point(113, 0)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(69, 73)
        PictureBox1.TabIndex = 12
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.Control
        Button1.Image = My.Resources.Resources.home
        Button1.ImageAlign = ContentAlignment.MiddleRight
        Button1.Location = New Point(3, 96)
        Button1.Name = "Button1"
        Button1.Size = New Size(277, 42)
        Button1.TabIndex = 13
        Button1.Text = "الصفحة الرئيسية"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = SystemColors.Control
        Button2.Image = My.Resources.Resources.calculator__2_
        Button2.ImageAlign = ContentAlignment.MiddleRight
        Button2.Location = New Point(3, 175)
        Button2.Name = "Button2"
        Button2.Size = New Size(277, 42)
        Button2.TabIndex = 14
        Button2.Text = "الأرقــــــــام"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' SplitContainer1
        ' 
        SplitContainer1.Location = New Point(0, 45)
        SplitContainer1.Name = "SplitContainer1"
        ' 
        ' SplitContainer1.Panel1
        ' 
        SplitContainer1.Panel1.BackColor = Color.RosyBrown
        SplitContainer1.Panel1.Controls.Add(Button4)
        SplitContainer1.Panel1.Controls.Add(PictureBox1)
        SplitContainer1.Panel1.Controls.Add(Button1)
        SplitContainer1.Panel1.Controls.Add(Button3)
        SplitContainer1.Panel1.Controls.Add(Button2)
        SplitContainer1.Panel1.RightToLeft = RightToLeft.Yes
        ' 
        ' SplitContainer1.Panel2
        ' 
        SplitContainer1.Panel2.BackColor = Color.SeaShell
        SplitContainer1.Panel2.Controls.Add(reset_btn)
        SplitContainer1.Panel2.Controls.Add(rslt_lbl)
        SplitContainer1.Panel2.Controls.Add(Label4)
        SplitContainer1.Panel2.Controls.Add(btn3)
        SplitContainer1.Panel2.Controls.Add(btn2)
        SplitContainer1.Panel2.Controls.Add(btn1)
        SplitContainer1.Panel2.Controls.Add(Label2)
        SplitContainer1.Panel2.Controls.Add(PictureBox2)
        SplitContainer1.Panel2.Controls.Add(TextBox3)
        SplitContainer1.Panel2.Controls.Add(TextBox1)
        SplitContainer1.Panel2.Controls.Add(TextBox2)
        SplitContainer1.Panel2.Controls.Add(Label6)
        SplitContainer1.Panel2.Controls.Add(Label7)
        SplitContainer1.Panel2.Controls.Add(Label1)
        SplitContainer1.Panel2.RightToLeft = RightToLeft.Yes
        SplitContainer1.RightToLeft = RightToLeft.Yes
        SplitContainer1.Size = New Size(835, 408)
        SplitContainer1.SplitterDistance = 256
        SplitContainer1.TabIndex = 13
        ' 
        ' reset_btn
        ' 
        reset_btn.BackColor = Color.Red
        reset_btn.FlatAppearance.BorderColor = SystemColors.ScrollBar
        reset_btn.FlatStyle = FlatStyle.Flat
        reset_btn.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        reset_btn.ForeColor = SystemColors.ButtonFace
        reset_btn.Location = New Point(367, 346)
        reset_btn.Name = "reset_btn"
        reset_btn.Size = New Size(137, 31)
        reset_btn.TabIndex = 53
        reset_btn.Text = "مـسـح الـكـل"
        reset_btn.UseVisualStyleBackColor = False
        ' 
        ' rslt_lbl
        ' 
        rslt_lbl.AutoSize = True
        rslt_lbl.Font = New Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point)
        rslt_lbl.ForeColor = Color.SteelBlue
        rslt_lbl.Location = New Point(402, 288)
        rslt_lbl.Name = "rslt_lbl"
        rslt_lbl.Size = New Size(38, 23)
        rslt_lbl.TabIndex = 52
        rslt_lbl.Text = "...."
        rslt_lbl.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(495, 255)
        Label4.Name = "Label4"
        Label4.Size = New Size(77, 24)
        Label4.TabIndex = 51
        Label4.Text = "الــنــاتــج"
        ' 
        ' btn3
        ' 
        btn3.FlatStyle = FlatStyle.System
        btn3.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        btn3.Location = New Point(320, 160)
        btn3.Name = "btn3"
        btn3.Size = New Size(62, 57)
        btn3.TabIndex = 50
        btn3.Text = "الضلع الثالث"
        btn3.UseVisualStyleBackColor = True
        ' 
        ' btn2
        ' 
        btn2.FlatStyle = FlatStyle.System
        btn2.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        btn2.ForeColor = SystemColors.ActiveCaptionText
        btn2.Location = New Point(402, 160)
        btn2.Name = "btn2"
        btn2.Size = New Size(62, 57)
        btn2.TabIndex = 49
        btn2.Text = "الضلع الثاني"
        btn2.UseVisualStyleBackColor = True
        ' 
        ' btn1
        ' 
        btn1.BackColor = Color.RosyBrown
        btn1.FlatStyle = FlatStyle.System
        btn1.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        btn1.ForeColor = Color.Black
        btn1.Location = New Point(483, 160)
        btn1.Name = "btn1"
        btn1.Size = New Size(62, 57)
        btn1.TabIndex = 48
        btn1.Text = "الضلع الأول"
        btn1.UseVisualStyleBackColor = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(421, 109)
        Label2.Name = "Label2"
        Label2.Size = New Size(151, 29)
        Label2.TabIndex = 47
        Label2.Text = "إخـتـر الـمـطـلـوب"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.Untitled_removebg_preview1
        PictureBox2.Location = New Point(3, 108)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(275, 269)
        PictureBox2.TabIndex = 46
        PictureBox2.TabStop = False
        ' 
        ' TextBox3
        ' 
        TextBox3.BackColor = SystemColors.HighlightText
        TextBox3.BorderStyle = BorderStyle.FixedSingle
        TextBox3.Cursor = Cursors.IBeam
        TextBox3.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox3.Location = New Point(52, 66)
        TextBox3.Name = "TextBox3"
        TextBox3.PlaceholderText = "الضلع الثالث"
        TextBox3.Size = New Size(122, 25)
        TextBox3.TabIndex = 45
        TextBox3.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = SystemColors.HighlightText
        TextBox1.BorderStyle = BorderStyle.FixedSingle
        TextBox1.Cursor = Cursors.IBeam
        TextBox1.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox1.Location = New Point(421, 66)
        TextBox1.Name = "TextBox1"
        TextBox1.PlaceholderText = "الضلع الأول"
        TextBox1.Size = New Size(122, 25)
        TextBox1.TabIndex = 44
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox2
        ' 
        TextBox2.BackColor = SystemColors.HighlightText
        TextBox2.BorderStyle = BorderStyle.FixedSingle
        TextBox2.Cursor = Cursors.IBeam
        TextBox2.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox2.Location = New Point(244, 66)
        TextBox2.Name = "TextBox2"
        TextBox2.PlaceholderText = "الضلع الثاني"
        TextBox2.Size = New Size(122, 25)
        TextBox2.TabIndex = 43
        TextBox2.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Rubik Black", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.Control
        Label3.Location = New Point(351, 14)
        Label3.Name = "Label3"
        Label3.Size = New Size(237, 64)
        Label3.TabIndex = 7
        Label3.Text = "الــحــاســبــة الــذكــيــة" & vbCrLf & vbCrLf
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.RosyBrown
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(0, -2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(835, 50)
        Panel1.TabIndex = 12
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatStyle = FlatStyle.Flat
        Button5.ForeColor = Color.RosyBrown
        Button5.Image = My.Resources.Resources.list1
        Button5.Location = New Point(784, -4)
        Button5.Name = "Button5"
        Button5.Size = New Size(48, 51)
        Button5.TabIndex = 10
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Form13
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(834, 450)
        Controls.Add(SplitContainer1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.Fixed3D
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MdiChildrenMinimizedAnchorBottom = False
        MinimizeBox = False
        Name = "Form13"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Smart Calculator | فيثاغورث | نظريات"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        SplitContainer1.Panel1.ResumeLayout(False)
        SplitContainer1.Panel2.ResumeLayout(False)
        SplitContainer1.Panel2.PerformLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).EndInit()
        SplitContainer1.ResumeLayout(False)
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Button3 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btn3 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents reset_btn As Button
    Friend WithEvents rslt_lbl As Label
    Friend WithEvents Label4 As Label
End Class
