﻿Public Class Form14
    Private Sub Form14_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label4.Visible = False
        rslt_lbl.Visible = False
    End Sub

    'SideBar 
    Private Sub Timer1_Tick(sender As Object, e As EventArgs)
        If SplitContainer1.SplitterDistance > 60 Then
            SplitContainer1.SplitterDistance -= 10
        Else
            Timer1.Enabled = False
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs)
        If SplitContainer1.SplitterDistance < 250 Then
            SplitContainer1.SplitterDistance += 10
        Else
            Timer2.Enabled = False
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If SplitContainer1.SplitterDistance > 60 Then
            Timer1.Enabled = True
        Else
            Timer2.Enabled = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Visible = False
        Form1.Visible = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Visible = False
        Form2.Visible = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Visible = False
        Form3.Visible = True
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Visible = False
        Form4.Visible = True
    End Sub   'End SideBar

    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        Else
            Dim nm4 = Double.Parse(TextBox4.Text)
            Dim nm5 = Double.Parse(TextBox5.Text)
            Dim res As Double

            res = Math.Sqrt(nm4 * nm5)

            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        Else
            Dim nm4 = Double.Parse(TextBox4.Text)
            Dim nm5 = Double.Parse(TextBox5.Text)
            Dim res As Double

            res = Math.Sqrt(nm4 * (nm4 + nm5))

            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        If TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        Else
            Dim nm4 = Double.Parse(TextBox4.Text)
            Dim nm5 = Double.Parse(TextBox5.Text)
            Dim res As Double

            res = Math.Sqrt(nm5 * (nm5 + nm4))

            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        If TextBox1.Text = "" Or TextBox5.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        ElseIf TextBox1.Text <> "" Or TextBox5.Text <> "" Then
            Dim nm1 = Double.Parse(TextBox1.Text)
            Dim nm5 = Double.Parse(TextBox5.Text)
            Dim res As Double

            res = (nm1 * nm1) / nm5

            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True

        ElseIf TextBox2.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        ElseIf TextBox2.Text <> "" Or TextBox4.Text <> "" Or TextBox5.Text <> "" Then
            Dim nm2 = Double.Parse(TextBox2.Text)
            Dim nm4 = Double.Parse(TextBox4.Text)
            Dim nm5 = Double.Parse(TextBox5.Text)
            Dim res As Double

            res = (nm2 * nm2) / (nm5 + nm4)

            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        If TextBox1.Text = "" Or TextBox4.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        ElseIf TextBox1.Text <> "" Or TextBox4.Text <> "" Then
            Dim nm1 = Double.Parse(TextBox1.Text)
            Dim nm4 = Double.Parse(TextBox4.Text)
            Dim res As Double

            res = (nm1 * nm1) / nm4

            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True

        ElseIf TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        ElseIf TextBox2.Text <> "" Or TextBox4.Text <> "" Or TextBox5.Text <> "" Then
            Dim nm3 = Double.Parse(TextBox3.Text)
            Dim nm4 = Double.Parse(TextBox4.Text)
            Dim nm5 = Double.Parse(TextBox5.Text)
            Dim res As Double

            res = (nm3 * nm3) / (nm4 + nm5)

            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub
End Class