﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form1))
        Button4 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        PictureBox1 = New PictureBox()
        Panel2 = New Panel()
        Label3 = New Label()
        Button5 = New Button()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        Button1 = New Button()
        SplitContainer1 = New SplitContainer()
        Label5 = New Label()
        Label4 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).BeginInit()
        SplitContainer1.Panel1.SuspendLayout()
        SplitContainer1.Panel2.SuspendLayout()
        SplitContainer1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = SystemColors.Control
        Button4.Image = My.Resources.Resources.mathematician
        Button4.ImageAlign = ContentAlignment.MiddleRight
        Button4.Location = New Point(3, 427)
        Button4.Name = "Button4"
        Button4.Size = New Size(287, 42)
        Button4.TabIndex = 6
        Button4.Text = "الــنظــريــات"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = SystemColors.Control
        Button3.Image = My.Resources.Resources.prototype
        Button3.ImageAlign = ContentAlignment.MiddleRight
        Button3.Location = New Point(3, 342)
        Button3.Name = "Button3"
        Button3.Size = New Size(287, 42)
        Button3.TabIndex = 5
        Button3.Text = "الــهــنــدســة"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = SystemColors.Control
        Button2.Image = My.Resources.Resources.calculator__2_
        Button2.ImageAlign = ContentAlignment.MiddleRight
        Button2.Location = New Point(3, 258)
        Button2.Name = "Button2"
        Button2.Size = New Size(287, 42)
        Button2.TabIndex = 4
        Button2.Text = "الأرقــــــــام"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.calculator__1_
        PictureBox1.Location = New Point(125, 29)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(69, 73)
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.DarkCyan
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Button5)
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(956, 51)
        Panel2.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Rubik Black", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.Control
        Label3.Location = New Point(370, 9)
        Label3.Name = "Label3"
        Label3.Size = New Size(237, 64)
        Label3.TabIndex = 4
        Label3.Text = "الــحــاســبــة الــذكــيــة" & vbCrLf & vbCrLf
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatStyle = FlatStyle.Flat
        Button5.ForeColor = Color.DarkCyan
        Button5.Image = My.Resources.Resources.list1
        Button5.Location = New Point(899, 0)
        Button5.Name = "Button5"
        Button5.Size = New Size(48, 51)
        Button5.TabIndex = 3
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 1
        ' 
        ' Timer2
        ' 
        Timer2.Interval = 1
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.Control
        Button1.Image = My.Resources.Resources.home
        Button1.ImageAlign = ContentAlignment.MiddleRight
        Button1.Location = New Point(3, 177)
        Button1.Name = "Button1"
        Button1.Size = New Size(287, 42)
        Button1.TabIndex = 3
        Button1.Text = "الصفحة الرئيسية"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' SplitContainer1
        ' 
        SplitContainer1.Location = New Point(0, 51)
        SplitContainer1.Name = "SplitContainer1"
        ' 
        ' SplitContainer1.Panel1
        ' 
        SplitContainer1.Panel1.BackColor = Color.DarkCyan
        SplitContainer1.Panel1.Controls.Add(Button4)
        SplitContainer1.Panel1.Controls.Add(PictureBox1)
        SplitContainer1.Panel1.Controls.Add(Button1)
        SplitContainer1.Panel1.Controls.Add(Button3)
        SplitContainer1.Panel1.Controls.Add(Button2)
        SplitContainer1.Panel1.RightToLeft = RightToLeft.Yes
        ' 
        ' SplitContainer1.Panel2
        ' 
        SplitContainer1.Panel2.BackColor = Color.Bisque
        SplitContainer1.Panel2.Controls.Add(Label5)
        SplitContainer1.Panel2.Controls.Add(Label4)
        SplitContainer1.Panel2.Controls.Add(Label2)
        SplitContainer1.Panel2.Controls.Add(Label1)
        SplitContainer1.Panel2.RightToLeft = RightToLeft.Yes
        SplitContainer1.RightToLeft = RightToLeft.Yes
        SplitContainer1.Size = New Size(956, 598)
        SplitContainer1.SplitterDistance = 318
        SplitContainer1.TabIndex = 5
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Rubik", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.ForeColor = Color.DarkCyan
        Label5.Location = New Point(125, 273)
        Label5.Name = "Label5"
        Label5.Size = New Size(484, 64)
        Label5.TabIndex = 3
        Label5.Text = "الحاسبة الذكية تطبيق تم تطويره بالكامل باللغة العربية" & vbCrLf & " ليقوم بحل مسائل الرياضيات " & vbCrLf
        Label5.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Rubik", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = Color.DarkCyan
        Label4.Location = New Point(166, 163)
        Label4.Name = "Label4"
        Label4.Size = New Size(380, 32)
        Label4.TabIndex = 2
        Label4.Text = "أهــــلا بـــك فــي الــحــاســبــة الــذكــيـة"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Comic Sans MS", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.ForeColor = Color.DarkGreen
        Label2.Location = New Point(97, 572)
        Label2.Name = "Label2"
        Label2.Size = New Size(46, 16)
        Label2.TabIndex = 1
        Label2.Text = "Mz_75"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("MV Boli", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(0, 572)
        Label1.Name = "Label1"
        Label1.Size = New Size(91, 17)
        Label1.TabIndex = 0
        Label1.Text = "Powered By "
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(953, 649)
        Controls.Add(SplitContainer1)
        Controls.Add(Panel2)
        ForeColor = SystemColors.ControlText
        FormBorderStyle = FormBorderStyle.Fixed3D
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "  Smart Calculator | الصفحة الرئيسية"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        SplitContainer1.Panel1.ResumeLayout(False)
        SplitContainer1.Panel2.ResumeLayout(False)
        SplitContainer1.Panel2.PerformLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).EndInit()
        SplitContainer1.ResumeLayout(False)
        ResumeLayout(False)
    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Button1 As Button
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
