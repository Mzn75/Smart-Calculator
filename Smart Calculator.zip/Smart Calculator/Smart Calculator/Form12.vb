﻿Public Class Form12
    Private Sub Form12_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Label4.Visible = False
        rslt_lbl.Visible = False
    End Sub

    'SideBar 
    Private Sub Timer1_Tick(sender As Object, e As EventArgs)
        If SplitContainer1.SplitterDistance > 60 Then
            SplitContainer1.SplitterDistance -= 10
        Else
            Timer1.Enabled = False
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs)
        If SplitContainer1.SplitterDistance < 250 Then
            SplitContainer1.SplitterDistance += 10
        Else
            Timer2.Enabled = False
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If SplitContainer1.SplitterDistance > 60 Then
            Timer1.Enabled = True
        Else
            Timer2.Enabled = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Visible = False
        Form1.Visible = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Visible = False
        Form2.Visible = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Visible = False
        Form3.Visible = True
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Visible = False
        Form4.Visible = True
    End Sub 'End SideBar

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If TextBox2.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")

        Else
            Dim nm2 = Double.Parse(TextBox2.Text)
            Dim res As Double

            res = (nm2 * nm2 * nm2)
            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If TextBox1.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")
        Else
            Dim nm1 = Double.Parse(TextBox1.Text)
            Dim res As Double

            res = 4 * (nm1 * nm1)
            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If TextBox1.Text = "" Then
            MsgBox(Prompt:="أدخل باقي المعطيات", Title:="Error")
        Else
            Dim nm1 = Double.Parse(TextBox1.Text)
            Dim res As Double
            Dim mg_calc As Double = nm1 * nm1

            res = 6 * mg_calc
            rslt_lbl.Text = res
            Label4.Visible = True
            rslt_lbl.Visible = True
        End If
    End Sub

    Private Sub reset_btn_Click(sender As Object, e As EventArgs) Handles reset_btn.Click

        TextBox1.Clear()
        TextBox2.Clear()
        Label4.ResetText()
        rslt_lbl.ResetText()

        Label4.Visible = False
        rslt_lbl.Visible = False
    End Sub
End Class