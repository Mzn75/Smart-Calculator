﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form5))
        Panel1 = New Panel()
        Button5 = New Button()
        Label3 = New Label()
        SplitContainer1 = New SplitContainer()
        Button4 = New Button()
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Label6 = New Label()
        reset_btn = New Button()
        Label7 = New Label()
        rslt_lbl = New Label()
        Label4 = New Label()
        TextBox1 = New TextBox()
        Label2 = New Label()
        Button7 = New Button()
        Button6 = New Button()
        Label1 = New Label()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        Panel1.SuspendLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).BeginInit()
        SplitContainer1.Panel1.SuspendLayout()
        SplitContainer1.Panel2.SuspendLayout()
        SplitContainer1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.SandyBrown
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(0, -4)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(801, 50)
        Panel1.TabIndex = 0
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatStyle = FlatStyle.Flat
        Button5.ForeColor = Color.Orange
        Button5.Image = My.Resources.Resources.list1
        Button5.Location = New Point(750, 4)
        Button5.Name = "Button5"
        Button5.Size = New Size(48, 43)
        Button5.TabIndex = 8
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Rubik Black", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.Control
        Label3.Location = New Point(351, 14)
        Label3.Name = "Label3"
        Label3.Size = New Size(237, 64)
        Label3.TabIndex = 7
        Label3.Text = "الــحــاســبــة الــذكــيــة" & vbCrLf & vbCrLf
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' SplitContainer1
        ' 
        SplitContainer1.Location = New Point(0, 43)
        SplitContainer1.Name = "SplitContainer1"
        ' 
        ' SplitContainer1.Panel1
        ' 
        SplitContainer1.Panel1.BackColor = Color.SandyBrown
        SplitContainer1.Panel1.Controls.Add(Button4)
        SplitContainer1.Panel1.Controls.Add(PictureBox1)
        SplitContainer1.Panel1.Controls.Add(Button1)
        SplitContainer1.Panel1.Controls.Add(Button3)
        SplitContainer1.Panel1.Controls.Add(Button2)
        SplitContainer1.Panel1.RightToLeft = RightToLeft.Yes
        ' 
        ' SplitContainer1.Panel2
        ' 
        SplitContainer1.Panel2.BackColor = Color.LightBlue
        SplitContainer1.Panel2.Controls.Add(Label6)
        SplitContainer1.Panel2.Controls.Add(reset_btn)
        SplitContainer1.Panel2.Controls.Add(Label7)
        SplitContainer1.Panel2.Controls.Add(rslt_lbl)
        SplitContainer1.Panel2.Controls.Add(Label4)
        SplitContainer1.Panel2.Controls.Add(TextBox1)
        SplitContainer1.Panel2.Controls.Add(Label2)
        SplitContainer1.Panel2.Controls.Add(Button7)
        SplitContainer1.Panel2.Controls.Add(Button6)
        SplitContainer1.Panel2.Controls.Add(Label1)
        SplitContainer1.Panel2.RightToLeft = RightToLeft.Yes
        SplitContainer1.RightToLeft = RightToLeft.Yes
        SplitContainer1.Size = New Size(801, 408)
        SplitContainer1.SplitterDistance = 267
        SplitContainer1.TabIndex = 1
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = SystemColors.Control
        Button4.Image = My.Resources.Resources.mathematician
        Button4.ImageAlign = ContentAlignment.MiddleRight
        Button4.Location = New Point(3, 353)
        Button4.Name = "Button4"
        Button4.Size = New Size(277, 42)
        Button4.TabIndex = 16
        Button4.Text = "الــنظــريــات"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.calculator__1_
        PictureBox1.Location = New Point(102, 9)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(69, 73)
        PictureBox1.TabIndex = 12
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.Control
        Button1.Image = My.Resources.Resources.home
        Button1.ImageAlign = ContentAlignment.MiddleRight
        Button1.Location = New Point(3, 104)
        Button1.Name = "Button1"
        Button1.Size = New Size(277, 42)
        Button1.TabIndex = 13
        Button1.Text = "الصفحة الرئيسية"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = SystemColors.Control
        Button3.Image = My.Resources.Resources.prototype
        Button3.ImageAlign = ContentAlignment.MiddleRight
        Button3.Location = New Point(3, 276)
        Button3.Name = "Button3"
        Button3.Size = New Size(277, 42)
        Button3.TabIndex = 15
        Button3.Text = "الــهــنــدســة"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = SystemColors.Control
        Button2.Image = My.Resources.Resources.calculator__2_
        Button2.ImageAlign = ContentAlignment.MiddleRight
        Button2.Location = New Point(3, 193)
        Button2.Name = "Button2"
        Button2.Size = New Size(277, 42)
        Button2.TabIndex = 14
        Button2.Text = "الأرقــــــــام"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.ForeColor = Color.DarkGreen
        Label6.Location = New Point(82, 382)
        Label6.Name = "Label6"
        Label6.Size = New Size(45, 16)
        Label6.TabIndex = 29
        Label6.Text = "Mz_75"
        ' 
        ' reset_btn
        ' 
        reset_btn.BackColor = Color.Red
        reset_btn.FlatAppearance.BorderColor = SystemColors.ScrollBar
        reset_btn.FlatStyle = FlatStyle.Flat
        reset_btn.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        reset_btn.ForeColor = SystemColors.ButtonFace
        reset_btn.Location = New Point(211, 329)
        reset_btn.Name = "reset_btn"
        reset_btn.Size = New Size(137, 31)
        reset_btn.TabIndex = 28
        reset_btn.Text = "مـسـح الـكـل"
        reset_btn.UseVisualStyleBackColor = False
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(3, 382)
        Label7.Name = "Label7"
        Label7.Size = New Size(73, 16)
        Label7.TabIndex = 28
        Label7.Text = "Powered By "
        ' 
        ' rslt_lbl
        ' 
        rslt_lbl.AutoSize = True
        rslt_lbl.Font = New Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point)
        rslt_lbl.ForeColor = Color.Peru
        rslt_lbl.Location = New Point(263, 287)
        rslt_lbl.Name = "rslt_lbl"
        rslt_lbl.Size = New Size(38, 23)
        rslt_lbl.TabIndex = 27
        rslt_lbl.Text = "...."
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(347, 264)
        Label4.Name = "Label4"
        Label4.Size = New Size(77, 24)
        Label4.TabIndex = 26
        Label4.Text = "الــنــاتــج"
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = Color.LightBlue
        TextBox1.BorderStyle = BorderStyle.FixedSingle
        TextBox1.Cursor = Cursors.IBeam
        TextBox1.Font = New Font("Comic Sans MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox1.Location = New Point(172, 68)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(212, 28)
        TextBox1.TabIndex = 4
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(392, 31)
        Label2.Name = "Label2"
        Label2.Size = New Size(126, 24)
        Label2.TabIndex = 3
        Label2.Text = "أدخل طول الضلع"
        ' 
        ' Button7
        ' 
        Button7.Cursor = Cursors.Hand
        Button7.FlatAppearance.BorderColor = SystemColors.HighlightText
        Button7.FlatAppearance.BorderSize = 2
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button7.ForeColor = SystemColors.ActiveCaptionText
        Button7.Location = New Point(148, 199)
        Button7.Name = "Button7"
        Button7.Size = New Size(101, 36)
        Button7.TabIndex = 2
        Button7.Text = "الـمـسـاحـة"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Cursor = Cursors.Hand
        Button6.FlatAppearance.BorderColor = SystemColors.HighlightText
        Button6.FlatAppearance.BorderSize = 2
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.ForeColor = SystemColors.ActiveCaptionText
        Button6.Location = New Point(291, 198)
        Button6.Name = "Button6"
        Button6.Size = New Size(101, 36)
        Button6.TabIndex = 1
        Button6.Text = "الـمـحـيـط"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(431, 149)
        Label1.Name = "Label1"
        Label1.Size = New Size(87, 29)
        Label1.TabIndex = 0
        Label1.Text = "إخــــتــــر"
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 1
        ' 
        ' Timer2
        ' 
        Timer2.Interval = 1
        ' 
        ' Form5
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ScrollBar
        ClientSize = New Size(800, 450)
        Controls.Add(SplitContainer1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.Fixed3D
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form5"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Smart Calculator | المربع | الهندسة"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        SplitContainer1.Panel1.ResumeLayout(False)
        SplitContainer1.Panel2.ResumeLayout(False)
        SplitContainer1.Panel2.PerformLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).EndInit()
        SplitContainer1.ResumeLayout(False)
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents Label3 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents reset_btn As Button
    Friend WithEvents rslt_lbl As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
End Class
