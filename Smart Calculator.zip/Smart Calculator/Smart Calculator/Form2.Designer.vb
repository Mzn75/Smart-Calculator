﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form2))
        Panel1 = New Panel()
        Label5 = New Label()
        Button5 = New Button()
        SplitContainer1 = New SplitContainer()
        Button4 = New Button()
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Button6 = New Button()
        Label6 = New Label()
        Label7 = New Label()
        rslt_lbl = New Label()
        Label1 = New Label()
        reset = New Button()
        Label4 = New Label()
        TextBox1 = New TextBox()
        mult = New Button()
        Label3 = New Label()
        plus = New Button()
        trh = New Button()
        div = New Button()
        Label2 = New Label()
        TextBox2 = New TextBox()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        Panel1.SuspendLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).BeginInit()
        SplitContainer1.Panel1.SuspendLayout()
        SplitContainer1.Panel2.SuspendLayout()
        SplitContainer1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(Button5)
        Panel1.Location = New Point(2, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(634, 50)
        Panel1.TabIndex = 0
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.FlatStyle = FlatStyle.Flat
        Label5.Font = New Font("Rubik Black", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.ForeColor = SystemColors.Control
        Label5.Location = New Point(273, 5)
        Label5.Name = "Label5"
        Label5.Size = New Size(237, 64)
        Label5.TabIndex = 5
        Label5.Text = "الــحــاســبــة الــذكــيــة" & vbCrLf & vbCrLf
        Label5.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatStyle = FlatStyle.Flat
        Button5.ForeColor = Color.DarkSlateGray
        Button5.Image = My.Resources.Resources.list1
        Button5.Location = New Point(575, 0)
        Button5.Name = "Button5"
        Button5.Size = New Size(48, 47)
        Button5.TabIndex = 4
        Button5.UseVisualStyleBackColor = True
        ' 
        ' SplitContainer1
        ' 
        SplitContainer1.Location = New Point(2, 47)
        SplitContainer1.Name = "SplitContainer1"
        ' 
        ' SplitContainer1.Panel1
        ' 
        SplitContainer1.Panel1.Controls.Add(Button4)
        SplitContainer1.Panel1.Controls.Add(PictureBox1)
        SplitContainer1.Panel1.Controls.Add(Button1)
        SplitContainer1.Panel1.Controls.Add(Button3)
        SplitContainer1.Panel1.Controls.Add(Button2)
        SplitContainer1.Panel1.RightToLeft = RightToLeft.Yes
        ' 
        ' SplitContainer1.Panel2
        ' 
        SplitContainer1.Panel2.BackColor = SystemColors.ScrollBar
        SplitContainer1.Panel2.Controls.Add(Button6)
        SplitContainer1.Panel2.Controls.Add(Label6)
        SplitContainer1.Panel2.Controls.Add(Label7)
        SplitContainer1.Panel2.Controls.Add(rslt_lbl)
        SplitContainer1.Panel2.Controls.Add(Label1)
        SplitContainer1.Panel2.Controls.Add(reset)
        SplitContainer1.Panel2.Controls.Add(Label4)
        SplitContainer1.Panel2.Controls.Add(TextBox1)
        SplitContainer1.Panel2.Controls.Add(mult)
        SplitContainer1.Panel2.Controls.Add(Label3)
        SplitContainer1.Panel2.Controls.Add(plus)
        SplitContainer1.Panel2.Controls.Add(trh)
        SplitContainer1.Panel2.Controls.Add(div)
        SplitContainer1.Panel2.Controls.Add(Label2)
        SplitContainer1.Panel2.Controls.Add(TextBox2)
        SplitContainer1.Panel2.RightToLeft = RightToLeft.Yes
        SplitContainer1.RightToLeft = RightToLeft.Yes
        SplitContainer1.Size = New Size(634, 483)
        SplitContainer1.SplitterDistance = 211
        SplitContainer1.TabIndex = 1
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = SystemColors.Control
        Button4.Image = My.Resources.Resources.mathematician
        Button4.ImageAlign = ContentAlignment.MiddleRight
        Button4.Location = New Point(3, 419)
        Button4.Name = "Button4"
        Button4.Size = New Size(197, 42)
        Button4.TabIndex = 11
        Button4.Text = "الــنظــريــات"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.calculator__1_
        PictureBox1.Location = New Point(72, 31)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(63, 73)
        PictureBox1.TabIndex = 7
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.Control
        Button1.Image = My.Resources.Resources.home
        Button1.ImageAlign = ContentAlignment.MiddleRight
        Button1.Location = New Point(3, 168)
        Button1.Name = "Button1"
        Button1.Size = New Size(197, 42)
        Button1.TabIndex = 8
        Button1.Text = "الصفحة الرئيسية"
        Button1.TextAlign = ContentAlignment.MiddleLeft
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = SystemColors.Control
        Button3.Image = My.Resources.Resources.prototype
        Button3.ImageAlign = ContentAlignment.MiddleRight
        Button3.Location = New Point(3, 334)
        Button3.Name = "Button3"
        Button3.Size = New Size(197, 42)
        Button3.TabIndex = 10
        Button3.Text = "الــهــنــدســة"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = SystemColors.Control
        Button2.Image = My.Resources.Resources.calculator__2_
        Button2.ImageAlign = ContentAlignment.MiddleRight
        Button2.Location = New Point(3, 250)
        Button2.Name = "Button2"
        Button2.Size = New Size(197, 42)
        Button2.TabIndex = 9
        Button2.Text = "الأرقــــــــام"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.BackColor = SystemColors.ScrollBar
        Button6.FlatAppearance.BorderColor = Color.White
        Button6.FlatAppearance.BorderSize = 2
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.Location = New Point(312, 253)
        Button6.Name = "Button6"
        Button6.Size = New Size(56, 56)
        Button6.TabIndex = 28
        Button6.Text = "√"
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.ForeColor = Color.DarkGreen
        Label6.Location = New Point(82, 460)
        Label6.Name = "Label6"
        Label6.Size = New Size(45, 16)
        Label6.TabIndex = 27
        Label6.Text = "Mz_75"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(3, 460)
        Label7.Name = "Label7"
        Label7.Size = New Size(73, 16)
        Label7.TabIndex = 26
        Label7.Text = "Powered By "
        ' 
        ' rslt_lbl
        ' 
        rslt_lbl.AutoSize = True
        rslt_lbl.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point)
        rslt_lbl.ForeColor = Color.DarkRed
        rslt_lbl.Location = New Point(122, 378)
        rslt_lbl.Name = "rslt_lbl"
        rslt_lbl.Size = New Size(37, 30)
        rslt_lbl.TabIndex = 25
        rslt_lbl.Text = "...."
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.ActiveCaptionText
        Label1.Location = New Point(259, 31)
        Label1.Name = "Label1"
        Label1.Size = New Size(125, 24)
        Label1.TabIndex = 14
        Label1.Text = "أدخل الرقم الأول"
        ' 
        ' reset
        ' 
        reset.BackColor = Color.Red
        reset.FlatStyle = FlatStyle.Flat
        reset.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        reset.ForeColor = SystemColors.Control
        reset.Location = New Point(45, 253)
        reset.Name = "reset"
        reset.Size = New Size(148, 56)
        reset.TabIndex = 23
        reset.Text = "مــســح الــكــل"
        reset.UseVisualStyleBackColor = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(246, 385)
        Label4.Name = "Label4"
        Label4.Size = New Size(77, 24)
        Label4.TabIndex = 24
        Label4.Text = "الــنــاتــج"
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = SystemColors.ScrollBar
        TextBox1.Font = New Font("Comic Sans MS", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox1.Location = New Point(258, 78)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(126, 26)
        TextBox1.TabIndex = 16
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' mult
        ' 
        mult.BackColor = SystemColors.ScrollBar
        mult.FlatAppearance.BorderColor = Color.White
        mult.FlatStyle = FlatStyle.Flat
        mult.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        mult.Location = New Point(45, 191)
        mult.Name = "mult"
        mult.Size = New Size(56, 56)
        mult.TabIndex = 21
        mult.Text = "x"
        mult.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.ActiveCaptionText
        Label3.Location = New Point(166, 138)
        Label3.Name = "Label3"
        Label3.Size = New Size(91, 24)
        Label3.TabIndex = 22
        Label3.Text = "إختر العملية"
        ' 
        ' plus
        ' 
        plus.BackColor = SystemColors.ScrollBar
        plus.FlatAppearance.BorderColor = Color.White
        plus.FlatAppearance.BorderSize = 2
        plus.FlatStyle = FlatStyle.Flat
        plus.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        plus.Location = New Point(137, 191)
        plus.Name = "plus"
        plus.Size = New Size(56, 56)
        plus.TabIndex = 18
        plus.Text = "+"
        plus.UseVisualStyleBackColor = False
        ' 
        ' trh
        ' 
        trh.BackColor = SystemColors.ScrollBar
        trh.FlatAppearance.BorderColor = Color.White
        trh.FlatAppearance.BorderSize = 2
        trh.FlatStyle = FlatStyle.Flat
        trh.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        trh.Location = New Point(226, 191)
        trh.Name = "trh"
        trh.Size = New Size(56, 56)
        trh.TabIndex = 19
        trh.Text = "-"
        trh.UseVisualStyleBackColor = False
        ' 
        ' div
        ' 
        div.BackColor = SystemColors.ScrollBar
        div.FlatAppearance.BorderColor = Color.White
        div.FlatAppearance.BorderSize = 2
        div.FlatStyle = FlatStyle.Flat
        div.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        div.Location = New Point(312, 191)
        div.Name = "div"
        div.Size = New Size(56, 56)
        div.TabIndex = 20
        div.Text = "÷"
        div.UseVisualStyleBackColor = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.ForeColor = SystemColors.ActiveCaptionText
        Label2.Location = New Point(33, 31)
        Label2.Name = "Label2"
        Label2.Size = New Size(126, 24)
        Label2.TabIndex = 15
        Label2.Text = "أدخل الرقم الثاني"
        ' 
        ' TextBox2
        ' 
        TextBox2.BackColor = SystemColors.ScrollBar
        TextBox2.Font = New Font("Comic Sans MS", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox2.Location = New Point(33, 78)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(126, 26)
        TextBox2.TabIndex = 17
        TextBox2.TextAlign = HorizontalAlignment.Center
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 1
        ' 
        ' Timer2
        ' 
        Timer2.Interval = 1
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.DarkSlateGray
        ClientSize = New Size(637, 530)
        Controls.Add(SplitContainer1)
        Controls.Add(Panel1)
        ForeColor = SystemColors.ActiveCaptionText
        FormBorderStyle = FormBorderStyle.Fixed3D
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form2"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Smart Calculator | حاسبة الأرقام"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        SplitContainer1.Panel1.ResumeLayout(False)
        SplitContainer1.Panel2.ResumeLayout(False)
        SplitContainer1.Panel2.PerformLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).EndInit()
        SplitContainer1.ResumeLayout(False)
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents rslt_lbl As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents reset As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents mult As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents plus As Button
    Friend WithEvents trh As Button
    Friend WithEvents div As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Button6 As Button
End Class
