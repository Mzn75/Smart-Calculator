﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form4))
        SplitContainer1 = New SplitContainer()
        Button4 = New Button()
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Button8 = New Button()
        Button7 = New Button()
        Label6 = New Label()
        Label7 = New Label()
        Label1 = New Label()
        Panel1 = New Panel()
        Button5 = New Button()
        Label3 = New Label()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        CType(SplitContainer1, ComponentModel.ISupportInitialize).BeginInit()
        SplitContainer1.Panel1.SuspendLayout()
        SplitContainer1.Panel2.SuspendLayout()
        SplitContainer1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' SplitContainer1
        ' 
        SplitContainer1.Location = New Point(0, 45)
        SplitContainer1.Name = "SplitContainer1"
        ' 
        ' SplitContainer1.Panel1
        ' 
        SplitContainer1.Panel1.BackColor = Color.Gold
        SplitContainer1.Panel1.Controls.Add(Button4)
        SplitContainer1.Panel1.Controls.Add(PictureBox1)
        SplitContainer1.Panel1.Controls.Add(Button1)
        SplitContainer1.Panel1.Controls.Add(Button3)
        SplitContainer1.Panel1.Controls.Add(Button2)
        SplitContainer1.Panel1.RightToLeft = RightToLeft.Yes
        ' 
        ' SplitContainer1.Panel2
        ' 
        SplitContainer1.Panel2.BackColor = Color.DodgerBlue
        SplitContainer1.Panel2.Controls.Add(Button8)
        SplitContainer1.Panel2.Controls.Add(Button7)
        SplitContainer1.Panel2.Controls.Add(Label6)
        SplitContainer1.Panel2.Controls.Add(Label7)
        SplitContainer1.Panel2.Controls.Add(Label1)
        SplitContainer1.Panel2.RightToLeft = RightToLeft.Yes
        SplitContainer1.RightToLeft = RightToLeft.Yes
        SplitContainer1.Size = New Size(801, 408)
        SplitContainer1.SplitterDistance = 280
        SplitContainer1.TabIndex = 11
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = SystemColors.Control
        Button4.Image = My.Resources.Resources.mathematician
        Button4.ImageAlign = ContentAlignment.MiddleRight
        Button4.Location = New Point(3, 354)
        Button4.Name = "Button4"
        Button4.Size = New Size(277, 42)
        Button4.TabIndex = 16
        Button4.Text = "الــنظــريــات"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.calculator__1_
        PictureBox1.Location = New Point(113, 0)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(69, 73)
        PictureBox1.TabIndex = 12
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.Control
        Button1.Image = My.Resources.Resources.home
        Button1.ImageAlign = ContentAlignment.MiddleRight
        Button1.Location = New Point(3, 95)
        Button1.Name = "Button1"
        Button1.Size = New Size(277, 42)
        Button1.TabIndex = 13
        Button1.Text = "الصفحة الرئيسية"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = SystemColors.Control
        Button3.Image = My.Resources.Resources.prototype
        Button3.ImageAlign = ContentAlignment.MiddleRight
        Button3.Location = New Point(3, 269)
        Button3.Name = "Button3"
        Button3.Size = New Size(277, 42)
        Button3.TabIndex = 15
        Button3.Text = "الــهــنــدســة"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = SystemColors.Control
        Button2.Image = My.Resources.Resources.calculator__2_
        Button2.ImageAlign = ContentAlignment.MiddleRight
        Button2.Location = New Point(3, 175)
        Button2.Name = "Button2"
        Button2.Size = New Size(277, 42)
        Button2.TabIndex = 14
        Button2.Text = "الأرقــــــــام"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.FlatStyle = FlatStyle.Flat
        Button8.Font = New Font("Rubik", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Button8.ForeColor = SystemColors.Control
        Button8.Location = New Point(79, 202)
        Button8.Name = "Button8"
        Button8.Size = New Size(167, 74)
        Button8.TabIndex = 32
        Button8.Text = "نــظــريــة إقــلــيــدس"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Font = New Font("Rubik", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Button7.ForeColor = SystemColors.Control
        Button7.Location = New Point(294, 110)
        Button7.Name = "Button7"
        Button7.Size = New Size(167, 74)
        Button7.TabIndex = 31
        Button7.Text = "نــظــريــة فــيــثــاغــورث"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.ForeColor = Color.DarkGreen
        Label6.Location = New Point(79, 380)
        Label6.Name = "Label6"
        Label6.Size = New Size(45, 16)
        Label6.TabIndex = 29
        Label6.Text = "Mz_75"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(3, 380)
        Label7.Name = "Label7"
        Label7.Size = New Size(73, 16)
        Label7.TabIndex = 28
        Label7.Text = "Powered By "
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(427, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(87, 29)
        Label1.TabIndex = 0
        Label1.Text = "إخــــتــــر"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Gold
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(0, -2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(801, 50)
        Panel1.TabIndex = 10
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatStyle = FlatStyle.Flat
        Button5.ForeColor = Color.Navy
        Button5.Image = My.Resources.Resources.list1
        Button5.Location = New Point(740, 0)
        Button5.Name = "Button5"
        Button5.Size = New Size(48, 47)
        Button5.TabIndex = 12
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Rubik Black", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.Control
        Label3.Location = New Point(277, 4)
        Label3.Name = "Label3"
        Label3.Size = New Size(237, 64)
        Label3.TabIndex = 7
        Label3.Text = "الــحــاســبــة الــذكــيــة" & vbCrLf & vbCrLf
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 1
        ' 
        ' Timer2
        ' 
        Timer2.Interval = 1
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(792, 450)
        Controls.Add(SplitContainer1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.Fixed3D
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form4"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Smart Calculator | نظريات"
        SplitContainer1.Panel1.ResumeLayout(False)
        SplitContainer1.Panel2.ResumeLayout(False)
        SplitContainer1.Panel2.PerformLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).EndInit()
        SplitContainer1.ResumeLayout(False)
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Button5 As Button
End Class
