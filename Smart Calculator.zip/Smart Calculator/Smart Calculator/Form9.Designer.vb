﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form9
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form9))
        Panel1 = New Panel()
        Button5 = New Button()
        Label3 = New Label()
        SplitContainer1 = New SplitContainer()
        Button4 = New Button()
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Label2 = New Label()
        PictureBox4 = New PictureBox()
        Label11 = New Label()
        TextBox4 = New TextBox()
        TextBox3 = New TextBox()
        Label6 = New Label()
        TextBox2 = New TextBox()
        Label7 = New Label()
        reset_btn = New Button()
        rslt_lbl = New Label()
        Label4 = New Label()
        TextBox1 = New TextBox()
        Button7 = New Button()
        Button6 = New Button()
        Label1 = New Label()
        Timer1 = New Timer(components)
        Timer2 = New Timer(components)
        Panel1.SuspendLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).BeginInit()
        SplitContainer1.Panel1.SuspendLayout()
        SplitContainer1.Panel2.SuspendLayout()
        SplitContainer1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.MediumSlateBlue
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(-2, -1)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(802, 49)
        Panel1.TabIndex = 0
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatStyle = FlatStyle.Flat
        Button5.ForeColor = Color.MediumSlateBlue
        Button5.Image = My.Resources.Resources.list1
        Button5.Location = New Point(751, 0)
        Button5.Name = "Button5"
        Button5.Size = New Size(48, 43)
        Button5.TabIndex = 12
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.FlatStyle = FlatStyle.Flat
        Label3.Font = New Font("Rubik Black", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.Control
        Label3.Location = New Point(338, 5)
        Label3.Name = "Label3"
        Label3.Size = New Size(237, 64)
        Label3.TabIndex = 11
        Label3.Text = "الــحــاســبــة الــذكــيــة" & vbCrLf & vbCrLf
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' SplitContainer1
        ' 
        SplitContainer1.Location = New Point(0, 41)
        SplitContainer1.Name = "SplitContainer1"
        ' 
        ' SplitContainer1.Panel1
        ' 
        SplitContainer1.Panel1.BackColor = Color.MediumSlateBlue
        SplitContainer1.Panel1.Controls.Add(Button4)
        SplitContainer1.Panel1.Controls.Add(PictureBox1)
        SplitContainer1.Panel1.Controls.Add(Button1)
        SplitContainer1.Panel1.Controls.Add(Button3)
        SplitContainer1.Panel1.Controls.Add(Button2)
        SplitContainer1.Panel1.RightToLeft = RightToLeft.Yes
        ' 
        ' SplitContainer1.Panel2
        ' 
        SplitContainer1.Panel2.BackColor = SystemColors.ScrollBar
        SplitContainer1.Panel2.Controls.Add(Label2)
        SplitContainer1.Panel2.Controls.Add(PictureBox4)
        SplitContainer1.Panel2.Controls.Add(Label11)
        SplitContainer1.Panel2.Controls.Add(TextBox4)
        SplitContainer1.Panel2.Controls.Add(TextBox3)
        SplitContainer1.Panel2.Controls.Add(Label6)
        SplitContainer1.Panel2.Controls.Add(TextBox2)
        SplitContainer1.Panel2.Controls.Add(Label7)
        SplitContainer1.Panel2.Controls.Add(reset_btn)
        SplitContainer1.Panel2.Controls.Add(rslt_lbl)
        SplitContainer1.Panel2.Controls.Add(Label4)
        SplitContainer1.Panel2.Controls.Add(TextBox1)
        SplitContainer1.Panel2.Controls.Add(Button7)
        SplitContainer1.Panel2.Controls.Add(Button6)
        SplitContainer1.Panel2.Controls.Add(Label1)
        SplitContainer1.Panel2.RightToLeft = RightToLeft.Yes
        SplitContainer1.RightToLeft = RightToLeft.Yes
        SplitContainer1.Size = New Size(802, 434)
        SplitContainer1.SplitterDistance = 267
        SplitContainer1.TabIndex = 1
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = SystemColors.Control
        Button4.Image = My.Resources.Resources.mathematician
        Button4.ImageAlign = ContentAlignment.MiddleRight
        Button4.Location = New Point(3, 357)
        Button4.Name = "Button4"
        Button4.Size = New Size(260, 42)
        Button4.TabIndex = 26
        Button4.Text = "الــنظــريــات"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.calculator__1_
        PictureBox1.Location = New Point(94, 13)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(69, 73)
        PictureBox1.TabIndex = 22
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.Control
        Button1.Image = My.Resources.Resources.home
        Button1.ImageAlign = ContentAlignment.MiddleRight
        Button1.Location = New Point(3, 108)
        Button1.Name = "Button1"
        Button1.Size = New Size(260, 42)
        Button1.TabIndex = 23
        Button1.Text = "الصفحة الرئيسية"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = SystemColors.Control
        Button3.Image = My.Resources.Resources.prototype
        Button3.ImageAlign = ContentAlignment.MiddleRight
        Button3.Location = New Point(3, 280)
        Button3.Name = "Button3"
        Button3.Size = New Size(260, 42)
        Button3.TabIndex = 25
        Button3.Text = "الــهــنــدســة"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = SystemColors.Control
        Button2.Image = My.Resources.Resources.calculator__2_
        Button2.ImageAlign = ContentAlignment.MiddleRight
        Button2.Location = New Point(3, 197)
        Button2.Name = "Button2"
        Button2.Size = New Size(260, 42)
        Button2.TabIndex = 24
        Button2.Text = "الأرقــــــــام"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(336, 13)
        Label2.Name = "Label2"
        Label2.Size = New Size(185, 29)
        Label2.TabIndex = 68
        Label2.Text = "أدخــــل الـمـعـطـيـات"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = My.Resources.Resources.arrow__1_
        PictureBox4.Location = New Point(3, 139)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(43, 32)
        PictureBox4.TabIndex = 67
        PictureBox4.TabStop = False
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label11.ForeColor = Color.MediumSlateBlue
        Label11.Location = New Point(3, 119)
        Label11.Name = "Label11"
        Label11.Size = New Size(198, 24)
        Label11.TabIndex = 66
        Label11.Text = "في حالة حساب المحيط فقط"
        ' 
        ' TextBox4
        ' 
        TextBox4.BackColor = SystemColors.ScrollBar
        TextBox4.BorderStyle = BorderStyle.FixedSingle
        TextBox4.Cursor = Cursors.IBeam
        TextBox4.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox4.Location = New Point(50, 146)
        TextBox4.Name = "TextBox4"
        TextBox4.PlaceholderText = "ادخل طول الضلع الرابع"
        TextBox4.Size = New Size(212, 25)
        TextBox4.TabIndex = 64
        TextBox4.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox3
        ' 
        TextBox3.BackColor = SystemColors.ScrollBar
        TextBox3.BorderStyle = BorderStyle.FixedSingle
        TextBox3.Cursor = Cursors.IBeam
        TextBox3.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox3.Location = New Point(286, 146)
        TextBox3.Name = "TextBox3"
        TextBox3.PlaceholderText = "أدخل الإرتــفــاع"
        TextBox3.Size = New Size(212, 25)
        TextBox3.TabIndex = 59
        TextBox3.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.ForeColor = Color.DarkGreen
        Label6.Location = New Point(79, 406)
        Label6.Name = "Label6"
        Label6.Size = New Size(45, 16)
        Label6.TabIndex = 56
        Label6.Text = "Mz_75"
        ' 
        ' TextBox2
        ' 
        TextBox2.BackColor = SystemColors.ScrollBar
        TextBox2.BorderStyle = BorderStyle.FixedSingle
        TextBox2.Cursor = Cursors.IBeam
        TextBox2.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox2.Location = New Point(50, 69)
        TextBox2.Name = "TextBox2"
        TextBox2.PlaceholderText = "ادخل طول القاعدة الثانية"
        TextBox2.Size = New Size(212, 25)
        TextBox2.TabIndex = 58
        TextBox2.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Comic Sans MS", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(0, 406)
        Label7.Name = "Label7"
        Label7.Size = New Size(73, 16)
        Label7.TabIndex = 54
        Label7.Text = "Powered By "
        ' 
        ' reset_btn
        ' 
        reset_btn.BackColor = Color.Red
        reset_btn.FlatAppearance.BorderColor = SystemColors.ScrollBar
        reset_btn.FlatStyle = FlatStyle.Flat
        reset_btn.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        reset_btn.ForeColor = SystemColors.ButtonFace
        reset_btn.Location = New Point(196, 377)
        reset_btn.Name = "reset_btn"
        reset_btn.Size = New Size(137, 31)
        reset_btn.TabIndex = 55
        reset_btn.Text = "مـسـح الـكـل"
        reset_btn.UseVisualStyleBackColor = False
        ' 
        ' rslt_lbl
        ' 
        rslt_lbl.AutoSize = True
        rslt_lbl.Font = New Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point)
        rslt_lbl.ForeColor = Color.DarkSlateBlue
        rslt_lbl.Location = New Point(248, 326)
        rslt_lbl.Name = "rslt_lbl"
        rslt_lbl.Size = New Size(38, 23)
        rslt_lbl.TabIndex = 53
        rslt_lbl.Text = "...."
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Rubik", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(360, 325)
        Label4.Name = "Label4"
        Label4.Size = New Size(77, 24)
        Label4.TabIndex = 52
        Label4.Text = "الــنــاتــج"
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = SystemColors.ScrollBar
        TextBox1.BorderStyle = BorderStyle.FixedSingle
        TextBox1.Cursor = Cursors.IBeam
        TextBox1.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        TextBox1.Location = New Point(286, 69)
        TextBox1.Name = "TextBox1"
        TextBox1.PlaceholderText = "أدخل طول القاعدة الأولى"
        TextBox1.Size = New Size(212, 25)
        TextBox1.TabIndex = 51
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' Button7
        ' 
        Button7.Cursor = Cursors.Hand
        Button7.FlatAppearance.BorderColor = SystemColors.HighlightText
        Button7.FlatAppearance.BorderSize = 2
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button7.ForeColor = SystemColors.ActiveCaptionText
        Button7.Location = New Point(108, 241)
        Button7.Name = "Button7"
        Button7.Size = New Size(102, 36)
        Button7.TabIndex = 49
        Button7.Text = "الـمـسـاحـة"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Cursor = Cursors.Hand
        Button6.FlatAppearance.BorderColor = SystemColors.HighlightText
        Button6.FlatAppearance.BorderSize = 2
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Rubik", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.ForeColor = SystemColors.ActiveCaptionText
        Button6.Location = New Point(231, 242)
        Button6.Name = "Button6"
        Button6.Size = New Size(102, 36)
        Button6.TabIndex = 48
        Button6.Text = "الـمـحـيـط"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Rubik", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(411, 227)
        Label1.Name = "Label1"
        Label1.Size = New Size(87, 29)
        Label1.TabIndex = 47
        Label1.Text = "إخــــتــــر"
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 1
        ' 
        ' Timer2
        ' 
        Timer2.Interval = 1
        ' 
        ' Form9
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ScrollBar
        ClientSize = New Size(800, 472)
        Controls.Add(SplitContainer1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.Fixed3D
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form9"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Smart Calculator | شبه المنحرف | الهندسة"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        SplitContainer1.Panel1.ResumeLayout(False)
        SplitContainer1.Panel2.ResumeLayout(False)
        SplitContainer1.Panel2.PerformLayout()
        CType(SplitContainer1, ComponentModel.ISupportInitialize).EndInit()
        SplitContainer1.ResumeLayout(False)
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents Label3 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents reset_btn As Button
    Friend WithEvents rslt_lbl As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label2 As Label
End Class
